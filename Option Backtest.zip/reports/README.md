# Reports Folder

This folder stores generated reports:
- Excel backtest results
- CSV exports
- Performance visualizations

All reports are timestamped for easy tracking.
