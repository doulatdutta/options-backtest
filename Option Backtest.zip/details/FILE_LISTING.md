# Complete File Listing

## Core Application Files

### Main Application
- `app.py` - Streamlit dashboard (14,270 chars)
  - Upload interface
  - Parameter configuration
  - Results visualization
  - Performance metrics

### Core Modules (`core/`)
- `parser.py` - TradingView parser (3,251 chars)
  - Excel file parsing
  - Trade pairing
  - Data validation

- `engine.py` - Backtest engine (5,497 chars)
  - Trade processing
  - P&L calculation
  - API integration

- `expiry_rules.py` - Expiry logic (2,354 chars)
  - Expiry date calculation
  - Rollover handling
  - Weekly options support

- `strike_rules.py` - Strike logic (2,676 chars)
  - ATM/ITM/OTM calculation
  - Strike rounding
  - Price adjustments

- `upstox_api.py` - API wrapper (4,813 chars)
  - Historical data fetching
  - Instrument lookup
  - Price retrieval

- `report.py` - Report generator (4,926 chars)
  - Excel report creation
  - Statistics calculation
  - Chart generation

## Configuration Files

### Config (`config/`)
- `credentials.json` - API credentials template
- `__init__.py` - Package initialization

## Documentation Files

### Guides
- `README.md` - Main documentation (9,522 chars)
- `SETUP.md` - Setup instructions (9,563 chars)
- `USER_GUIDE.md` - Usage guide (13,700 chars)
- `QUICKSTART.md` - Quick start (1,200+ chars)
- `DEPLOYMENT_CHECKLIST.md` - Deployment guide

### Folder Docs
- `data/README.md` - Data folder guide (376 chars)
- `reports/README.md` - Reports folder guide (172 chars)

## Data Files

### Sample Data
- `data/sample_tradingview_export.csv` - Sample input

## Installation Scripts

### Automated Setup
- `install.bat` - Windows installer
- `install.sh` - Unix installer (macOS/Linux)

## Dependencies

### Python Packages
- `requirements.txt` - Package list

---

## Folder Structure

```
options_backtester/
│
├── app.py                          # Main application
├── requirements.txt                # Dependencies
├── README.md                       # Main docs
├── SETUP.md                        # Setup guide
├── USER_GUIDE.md                   # User guide
├── QUICKSTART.md                   # Quick start
├── DEPLOYMENT_CHECKLIST.md         # Deployment
├── install.bat                     # Windows install
├── install.sh                      # Unix install
├── __init__.py                     # Package init
│
├── config/
│   ├── credentials.json            # API config
│   └── __init__.py
│
├── core/
│   ├── __init__.py
│   ├── parser.py                   # Data parser
│   ├── engine.py                   # Backtest engine
│   ├── expiry_rules.py             # Expiry logic
│   ├── strike_rules.py             # Strike logic
│   ├── upstox_api.py               # API wrapper
│   └── report.py                   # Reports
│
├── data/
│   ├── README.md
│   └── sample_tradingview_export.csv
│
└── reports/
    └── README.md
```

---

**Total Files**: 21
**Lines of Code**: 2,500+
**Ready for**: ✅ Production Deployment
